/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./TextAreaPCF/TextArea.tsx"
/*!**********************************!*\
  !*** ./TextAreaPCF/TextArea.tsx ***!
  \**********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   TextArea: () => (/* binding */ TextArea)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-components */ \"@fluentui/react-components\");\n/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__);\n\n\nclass TextArea extends react__WEBPACK_IMPORTED_MODULE_0__.Component {\n  constructor(props) {\n    super(props);\n    this.state = {\n      draftValue: props.value\n    };\n  }\n  componentDidUpdate(prevProps) {\n    if (prevProps.value !== this.props.value && this.props.value !== this.state.draftValue) {\n      this.setState({\n        draftValue: this.props.value\n      });\n    }\n  }\n  render() {\n    var currentLength = this.state.draftValue.length;\n    var hasReachedMaxLength = currentLength >= this.props.maxLength;\n    var showRequiredError = this.props.isRequired && currentLength === 0;\n    var progressPercent = Math.max(0, Math.min(100, currentLength / this.props.maxLength * 100));\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      style: {\n        fontFamily: \"Segoe UI, Arial, sans-serif\",\n        fontSize: \"14px\",\n        color: \"#242424\",\n        width: \"100%\",\n        boxSizing: \"border-box\",\n        border: \"none\"\n      }\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      style: {\n        display: \"flex\",\n        alignItems: \"center\",\n        gap: \"6px\",\n        marginBottom: \"8px\"\n      }\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n      style: {\n        fontSize: \"16px\",\n        lineHeight: \"22px\",\n        color: \"#201f1e\",\n        fontWeight: 600\n      }\n    }, this.props.title, this.props.isRequired ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n      style: {\n        color: \"#a80000\"\n      }\n    }, \" *\") : null), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n      title: this.props.tooltipText,\n      style: {\n        cursor: \"default\",\n        color: \"#605e5c\",\n        border: \"1px solid #8a8886\",\n        borderRadius: \"50%\",\n        width: \"14px\",\n        height: \"14px\",\n        display: \"inline-flex\",\n        alignItems: \"center\",\n        justifyContent: \"center\",\n        fontSize: \"9px\",\n        fontWeight: 600,\n        lineHeight: \"1\",\n        userSelect: \"none\"\n      }\n    }, \"i\")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      style: {\n        display: \"flex\",\n        alignItems: \"center\",\n        gap: \"6px\",\n        color: \"#605e5c\",\n        fontSize: \"14px\",\n        marginBottom: \"8px\"\n      }\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n      style: {\n        color: \"#605e5c\",\n        border: \"1px solid #c8c6c4\",\n        borderRadius: \"3px\",\n        width: \"14px\",\n        height: \"14px\",\n        display: \"inline-flex\",\n        alignItems: \"center\",\n        justifyContent: \"center\",\n        lineHeight: \"1\",\n        userSelect: \"none\",\n        backgroundColor: \"#edebe9\"\n      }\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"svg\", {\n      width: \"10\",\n      height: \"10\",\n      viewBox: \"0 0 16 16\",\n      \"aria-hidden\": \"true\",\n      focusable: \"false\"\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"path\", {\n      d: \"M2.5 3.5A1.5 1.5 0 0 1 4 2h8a1.5 1.5 0 0 1 1.5 1.5v5A1.5 1.5 0 0 1 12 10H8l-2.4 2.1A.5.5 0 0 1 4.8 11.7V10H4a1.5 1.5 0 0 1-1.5-1.5z\",\n      fill: \"#605e5c\"\n    }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", null, this.props.helpText)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Textarea, {\n      value: this.state.draftValue,\n      disabled: this.props.isDisabled,\n      maxLength: this.props.maxLength,\n      textarea: {\n        wrap: \"soft\"\n      },\n      onChange: event => {\n        var nextValue = event.currentTarget.value;\n        this.setState({\n          draftValue: nextValue\n        });\n        this.props.onValueChange(nextValue);\n      },\n      onBlur: () => {\n        this.props.onValueCommit(this.state.draftValue);\n      },\n      style: {\n        width: \"100%\",\n        minHeight: \"88px\",\n        boxSizing: \"border-box\",\n        resize: \"vertical\",\n        overflowY: \"auto\",\n        overflowX: \"hidden\",\n        whiteSpace: \"pre-wrap\",\n        overflowWrap: \"break-word\",\n        wordBreak: \"break-word\",\n        borderWidth: \"1px\",\n        borderStyle: \"solid\",\n        borderColor: showRequiredError ? \"#a80000\" : \"#8a8886\",\n        borderRadius: \"2px\",\n        backgroundColor: \"#ffffff\"\n      }\n    }), showRequiredError ? (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      style: {\n        color: \"#a80000\",\n        fontSize: \"12px\",\n        marginTop: \"4px\",\n        textAlign: \"left\"\n      }\n    }, \"Please enter your answer.\")) : null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      style: {\n        display: \"flex\",\n        flexDirection: \"column\",\n        alignItems: \"flex-end\",\n        gap: \"6px\",\n        marginTop: \"10px\",\n        fontSize: \"12px\",\n        fontWeight: 600,\n        textAlign: \"right\",\n        color: \"#605e5c\"\n      }\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", null, \"Maximum \", this.props.maxLength, \" characters\"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      style: {\n        width: \"170px\",\n        height: \"4px\",\n        backgroundColor: \"#e1dfdd\",\n        borderRadius: \"999px\",\n        overflow: \"hidden\"\n      }\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      style: {\n        width: \"\".concat(progressPercent, \"%\"),\n        height: \"100%\",\n        backgroundColor: showRequiredError ? \"#a80000\" : \"#5b5fc7\",\n        borderRadius: \"999px\"\n      }\n    })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"span\", {\n      style: {\n        color: hasReachedMaxLength ? \"#a80000\" : \"#605e5c\"\n      }\n    }, currentLength, \" / \", this.props.maxLength, \" Characters\")));\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./TextAreaPCF/TextArea.tsx?\n}");

/***/ },

/***/ "./TextAreaPCF/index.ts"
/*!******************************!*\
  !*** ./TextAreaPCF/index.ts ***!
  \******************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   TextAreaPCF: () => (/* binding */ TextAreaPCF)\n/* harmony export */ });\n/* harmony import */ var _TextArea__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TextArea */ \"./TextAreaPCF/TextArea.tsx\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nclass TextAreaPCF {\n  resolveIsRequired(requiredLevel) {\n    if (typeof requiredLevel === \"string\") {\n      var normalizedRequiredLevel = requiredLevel.toLowerCase();\n      return normalizedRequiredLevel === \"required\" || normalizedRequiredLevel === \"applicationrequired\" || normalizedRequiredLevel === \"systemrequired\";\n    }\n    if (typeof requiredLevel === \"number\") {\n      return requiredLevel >= 2;\n    }\n    if (requiredLevel !== null && requiredLevel !== undefined) {\n      try {\n        var serializedLevel = JSON.stringify(requiredLevel).toLowerCase();\n        return serializedLevel.includes(\"required\") && !serializedLevel.includes(\"recommended\");\n      } catch (error) {\n        return false;\n      }\n    }\n    return false;\n  }\n  /**\n   * Empty constructor.\n   */\n  constructor() {\n    this.currentValue = \"\";\n    this.pendingValue = null;\n    this.notifyTimerId = undefined;\n  }\n  queueNotifyOutputChanged() {\n    if (this.notifyTimerId !== undefined) {\n      window.clearTimeout(this.notifyTimerId);\n    }\n    this.notifyTimerId = window.setTimeout(() => {\n      this.notifyTimerId = undefined;\n      this.notifyOutputChanged();\n    }, 200);\n  }\n  flushNotifyOutputChanged() {\n    if (this.notifyTimerId !== undefined) {\n      window.clearTimeout(this.notifyTimerId);\n      this.notifyTimerId = undefined;\n    }\n    this.notifyOutputChanged();\n  }\n  /**\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\n   * Data-set values are not initialized here, use updateView.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\n   */\n  init(context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n  }\n  /**\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\n   * @returns ReactElement root react element for the control\n   */\n  updateView(context) {\n    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;\n    var boundValue = (_a = context.parameters.TextArea.raw) !== null && _a !== void 0 ? _a : \"\";\n    if (this.pendingValue === null) {\n      this.currentValue = boundValue;\n    } else if (boundValue === this.pendingValue) {\n      this.currentValue = boundValue;\n      this.pendingValue = null;\n    }\n    var textAreaParameter = context.parameters.TextArea;\n    var titleRaw = (_c = (_b = context.parameters.Title.raw) === null || _b === void 0 ? void 0 : _b.trim()) !== null && _c !== void 0 ? _c : \"\";\n    var title = titleRaw.length > 0 ? titleRaw : \"How do you use your knowledge and skills to help others?\";\n    var helpTextRaw = (_e = (_d = context.parameters.HelpText.raw) === null || _d === void 0 ? void 0 : _d.trim()) !== null && _e !== void 0 ? _e : \"\";\n    var helpText = helpTextRaw.length > 0 ? helpTextRaw : \"Examples include promoting diversity and inclusion in your technical community or events, volunteering, coaching, using technology to advance social good, etc.\";\n    var tooltipTextRaw = (_g = (_f = context.parameters.TooltipText.raw) === null || _f === void 0 ? void 0 : _f.trim()) !== null && _g !== void 0 ? _g : \"\";\n    var tooltipText = tooltipTextRaw.length > 0 ? tooltipTextRaw : \"More information\";\n    var configuredMaxLength = (_h = context.parameters.MaxLength.raw) !== null && _h !== void 0 ? _h : 1000;\n    var maxLength = configuredMaxLength > 0 ? configuredMaxLength : 1000;\n    var requiredLevel = (_j = textAreaParameter.attributes) === null || _j === void 0 ? void 0 : _j.RequiredLevel;\n    var isRequired = this.resolveIsRequired(requiredLevel);\n    var isDisabled = (_k = context.mode.isControlDisabled) !== null && _k !== void 0 ? _k : false;\n    var props = {\n      value: this.currentValue,\n      title,\n      helpText,\n      tooltipText,\n      maxLength,\n      isRequired,\n      isDisabled,\n      onValueChange: value => {\n        this.currentValue = value;\n        this.pendingValue = value;\n        this.queueNotifyOutputChanged();\n      },\n      onValueCommit: value => {\n        this.currentValue = value;\n        this.pendingValue = value;\n        this.flushNotifyOutputChanged();\n      }\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_TextArea__WEBPACK_IMPORTED_MODULE_0__.TextArea, props);\n  }\n  /**\n   * It is called by the framework prior to a control receiving new data.\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as \"bound\" or \"output\"\n   */\n  getOutputs() {\n    return {\n      TextArea: this.currentValue\n    };\n  }\n  /**\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\n   */\n  destroy() {\n    if (this.notifyTimerId !== undefined) {\n      window.clearTimeout(this.notifyTimerId);\n      this.notifyTimerId = undefined;\n    }\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./TextAreaPCF/index.ts?\n}");

/***/ },

/***/ "@fluentui/react-components"
/*!************************************!*\
  !*** external "FluentUIReactv940" ***!
  \************************************/
(module) {

module.exports = FluentUIReactv940;

/***/ },

/***/ "react"
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
(module) {

module.exports = Reactv16;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		if (!(moduleId in __webpack_modules__)) {
/******/ 			delete __webpack_module_cache__[moduleId];
/******/ 			var e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./TextAreaPCF/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('MDT.TextAreaPCF', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.TextAreaPCF);
} else {
	var MDT = MDT || {};
	MDT.TextAreaPCF = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.TextAreaPCF;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}